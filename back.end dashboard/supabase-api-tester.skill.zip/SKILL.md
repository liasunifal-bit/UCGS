---
name: supabase-api-tester
description: "Especialista em testes de API Postman para Supabase com foco em Row Level Security (RLS). Use para: validar operações CRUD, testar políticas de segurança RLS, configurar ambiente Postman para Supabase e identificar falhas de permissão."
---

# Supabase API Tester

Esta skill orienta a criação e execução de testes completos no Postman para validar operações CRUD em tabelas do Supabase, com foco rigoroso em segurança e Row Level Security (RLS).

## Fluxo de Trabalho

1. **Coleta de Informações**: Verifique se possui o nome da tabela, colunas (tipos), exemplo de registro, políticas RLS e tipos de usuários.
2. **Configuração do Ambiente**: Oriente a configuração de variáveis no Postman (base_url, table, anon_key, jwt_user_1, jwt_user_2, record_id).
3. **Execução de Testes CRUD**: Siga a ordem lógica (POST -> GET -> PATCH -> DELETE).
4. **Validação de RLS**: Repita os testes com diferentes tokens (anon, user_1, user_2, admin) para garantir que as políticas funcionam como esperado.
5. **Testes Negativos**: Force falhas para validar a robustez da API.

## Regras de Segurança e Operação

- **Nunca** use \`service_role_key\` para simular acessos de cliente/front-end.
- **Sempre** use \`apikey = anon_key\` e \`Authorization = Bearer <JWT>\` para testes realistas.
- **Obrigatório**: PATCH e DELETE devem sempre incluir filtros (\`id=eq.X\`) para evitar alterações em massa acidentais.
- **Validação**: Não verifique apenas o status code; valide se o corpo da resposta e a persistência no banco condizem com a política RLS.

## Formato de Resposta Padrão

Para cada teste solicitado, forneça:

1. **Resumo do Cenário**: Tabela e objetivo do teste.
2. **Checklist Postman**:
   - **Method/URL**: Ex: \`POST {{base_url}}/rest/v1/{{table}}\`
   - **Headers**: \`apikey\`, \`Authorization\`, \`Content-Type\`, \`Prefer\`.
   - **Params**: Filtros e seleções.
   - **Body**: JSON formatado.
3. **Resultado Esperado**: Status code e comportamento da RLS.
4. **O que o teste valida**: Pontos específicos de segurança ou lógica.
5. **Teste de RLS**: Sugestão de repetição com outros tokens.
6. **Riscos e Próximo Passo**: Erros comuns e o teste lógico seguinte.

## Recursos Disponíveis

- **Templates**: \`/home/ubuntu/skills/supabase-api-tester/templates/postman_env.json\` (Modelo de ambiente Postman).

## Exemplos de Filtros Comuns (Params)

- Seleção: \`select=*\` ou \`select=id,nome\`
- Igualdade: \`id=eq.1\`
- Paginação: Header \`Range: 0-9\`
- Retorno de Dados: Header \`Prefer: return=representation\`
